# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['browserstack_lesson']

package_data = \
{'': ['*']}

install_requires = \
['Appium-Python-Client>=2.6.1,<3.0.0',
 'allure-pytest>=2.10.0,<3.0.0',
 'pydantic>=1.10.2,<2.0.0',
 'pytest-xdist>=2.5.0,<3.0.0',
 'pytest>=7.1.3,<8.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'requests>=2.28.1,<3.0.0',
 'selene>=2.0.0-beta.8,<3.0.0']

setup_kwargs = {
    'name': 'browserstack-lesson',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'OlgaZtv',
    'author_email': 'zatulivetrova@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
